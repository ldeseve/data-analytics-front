import React, {useEffect, useState} from 'react';
import {Card, CardBody, CardSubtitle, CardTitle} from 'reactstrap';
import Chart from 'react-apexcharts';
import axios from 'axios';
import moment from 'moment';

const SalesChart = () => {
    const [chartData, setChartData] = useState({
        series: [
            {
                name: 'Total Voted Up',
                data: []
            },
            {
                name: 'Total Voted Down',
                data: []
            }
        ],
        options: {
            chart: {
                type: 'area'
            },
            dataLabels: {
                enabled: false
            },
            grid: {
                strokeDashArray: 3
            },
            stroke: {
                curve: 'smooth',
                width: 1
            },
            xaxis: {
                categories: []
            },
            colors: ['#008FFB', '#FF4560'] // Blue for Total Voted Up and Red for Total Voted Down
        }
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('https://8g8j7exfd7.execute-api.us-east-1.amazonaws.com/dev1/data');
                console.log('API Response:', response.data); // Log the API response
                const fetchedData = response.data;

                // Process the data for the chart
                const months = fetchedData.map((item) => moment(item.update_month).format('MMM'));
                const totalVotedUp = fetchedData.map((item) => item.total_voted_up);
                const totalVotedDown = fetchedData.map((item) => item.total_voted_down);

                setChartData({
                    series: [
                        {
                            name: 'Total Voted Up',
                            data: totalVotedUp
                        },
                        {
                            name: 'Total Voted Down',
                            data: totalVotedDown
                        }
                    ],
                    options: {
                        chart: {
                            type: 'area'
                        },
                        dataLabels: {
                            enabled: false
                        },
                        grid: {
                            strokeDashArray: 3
                        },
                        stroke: {
                            curve: 'smooth',
                            width: 1
                        },
                        xaxis: {
                            categories: months
                        },
                        colors: ['#008FFB', '#FF4560']
                    }
                });
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <Card>
            <CardBody>
                <CardTitle tag="h5">Sales Summary</CardTitle>
                <CardSubtitle className="text-muted" tag="h6">
                    Yearly Sales Report
                </CardSubtitle>
                <Chart type="area" width="100%" height="390" options={chartData.options} series={chartData.series} />
            </CardBody>
        </Card>
    );
};

export default SalesChart;
