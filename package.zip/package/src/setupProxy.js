const {createProxyMiddleware} = require('http-proxy-middleware');

module.exports = function (app) {
    app.use(
        '/api',
        createProxyMiddleware({
            target: 'https://8g8j7exfd7.execute-api.us-east-1.amazonaws.com/dev1/app',
            changeOrigin: true,
            pathRewrite: {
                '^/api': '/dev1' // rewrite path
            }
        })
    );
};
